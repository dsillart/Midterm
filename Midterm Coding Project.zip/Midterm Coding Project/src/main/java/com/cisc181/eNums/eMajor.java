package com.cisc181.eNums;

public enum eMajor {
BUSINESS, COMPSI, CHEM, PHYSICS, NURSING 
}